If you get an untrusted security error attempting to install I-Doser on your Mac then it is because your Mac's security settings only allows installs from the Mac App Store.

Please make the following changes on your Mac and then reinstall I-Doser

Go to your System Preferences App
(Finder / Applications / System Preferences)
Select Security & Privacy
Click the LOCK icon in the lower right allow editing of settings
Enter your system password, if prompted

Change the following setting
Allow Apps Downloaded from: Select "Anywhere"

A setting of Mac App Store or Mac App Store and Identified might now allow I-Doser to install.

Click to LOCK icon in the lower right to re-lock settings.

Close settings app and re-install I-Doser